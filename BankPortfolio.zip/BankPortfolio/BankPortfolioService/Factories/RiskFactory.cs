﻿using BankPortfolio.Core.Enums;
using BankPortfolio.Core.Interface;
using BankPortfolioService.Services;
using System;

namespace BankPortfolioService.Factories
{
    static class RiskFactory
    {
        public static IRisk Create(TypeRisk risk)
        {
            return Create(risk.ToString());
        }

        public static IRisk Create(string risk)
        {
            switch (risk)
            {
                case "LowRisk":
                    return new LowRiskService();
                case "MediumRisk":
                    return new MediumRiskService();
                case "HighRisk":
                    return new HighRiskService();
                default:
                    throw new NotImplementedException();
            }
        }
    }
}