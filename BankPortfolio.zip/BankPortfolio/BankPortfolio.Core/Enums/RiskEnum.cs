﻿namespace BankPortfolio.Core.Enums
{
    public enum NoneRisk { NONERISK }

    public enum TypeRisk { LowRisk, MediumRisk, HighRisk }

    public enum SectorRisk { Private, Public }
}