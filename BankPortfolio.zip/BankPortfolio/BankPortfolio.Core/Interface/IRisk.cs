﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankPortfolio.Core.Interface
{
    public interface IRisk
    {
        string Type { get; }
        bool CalculateRisk(ITrade trade);
    }
}